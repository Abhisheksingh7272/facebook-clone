import "./rightsidebar.css";
const RightSidebar = () => {
    return (
        <div className='right'>
            
        </div>
    )
}

export default RightSidebar
